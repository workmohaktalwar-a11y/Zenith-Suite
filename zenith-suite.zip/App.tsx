import React, { useState, useEffect } from 'react';
import { getCurrentUser, logoutUser } from './services/authService';
import Login from './components/Login';
import SignUp from './components/SignUp';
import MainAppLayout from './components/MainAppLayout';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoginView, setIsLoginView] = useState(true);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for user session on initial load
    if (getCurrentUser()) {
      setIsAuthenticated(true);
    }
    setIsLoading(false);
  }, []);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    logoutUser();
    setIsAuthenticated(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-900">
        <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent border-solid rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen font-sans text-gray-800 dark:text-gray-200">
      {isAuthenticated ? (
        <MainAppLayout onLogout={handleLogout} />
      ) : (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-800 p-4">
            <div className="w-full max-w-md p-8 space-y-8 bg-white rounded-2xl shadow-xl dark:bg-gray-900">
                {isLoginView ? (
                    <Login onLogin={handleLogin} onSwitchToSignUp={() => setIsLoginView(false)} />
                ) : (
                    <SignUp onSignUp={handleLogin} onSwitchToLogin={() => setIsLoginView(true)} />
                )}
            </div>
        </div>
      )}
    </div>
  );
};

export default App;
