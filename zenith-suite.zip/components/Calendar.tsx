import React, { useState, useEffect, useMemo } from 'react';
import Modal from './Modal';
import { BriefcaseIcon, UsersIcon } from './icons';
import { getEvents, saveEvent, CalendarEvent, EventType } from '../services/calendarService';

const Calendar: React.FC = () => {
  const [date, setDate] = useState(new Date());
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [eventType, setEventType] = useState<EventType | null>(null);
  const [events, setEvents] = useState<Record<string, CalendarEvent[]>>({});
  const [selectedDate, setSelectedDate] = useState<string | null>(null);


  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const year = date.getFullYear();
  const month = date.getMonth();

  const firstDayOfMonth = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const loadEvents = () => {
    const allEvents = getEvents();
    const eventsMap: Record<string, CalendarEvent[]> = {};
    allEvents.forEach(event => {
      const dateKey = event.date;
      if (!eventsMap[dateKey]) {
        eventsMap[dateKey] = [];
      }
      eventsMap[dateKey].push(event);
    });
    setEvents(eventsMap);
  };

  useEffect(() => {
    loadEvents();
  }, []);

  const handlePrevMonth = () => {
    setDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setDate(new Date(year, month + 1, 1));
  };
  
  const handleOpenAddModal = (type: EventType) => {
    setEventType(type);
    setIsAddModalOpen(true);
  };
  
  const handleCloseAddModal = () => {
    setIsAddModalOpen(false);
    setEventType(null);
  };

  const handleOpenViewModal = (dateStr: string) => {
    setSelectedDate(dateStr);
    setIsViewModalOpen(true);
  };

  const handleCloseViewModal = () => {
    setIsViewModalOpen(false);
    setSelectedDate(null);
  };

  const handleSaveEvent = (e: React.FormEvent) => {
      e.preventDefault();
      const formData = new FormData(e.target as HTMLFormElement);
      const eventData = Object.fromEntries(formData.entries());
      
      if (eventType && eventData.title && eventData.date && eventData.description) {
         saveEvent({
            type: eventType,
            title: eventData.title as string,
            date: eventData.date as string,
            description: eventData.description as string,
         });
         loadEvents(); // Reload events to update UI
         handleCloseAddModal();
      }
  };

  const today = new Date();

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Calendar</h1>
      <p className="mt-1 text-gray-600 dark:text-gray-400">Your monthly schedule at a glance.</p>
      
      <div className="mt-8 max-w-3xl mx-auto bg-white dark:bg-gray-800 p-6 rounded-lg shadow-soft">
        <div className="flex items-center justify-between mb-4">
           <div className="flex items-center gap-2">
            <h2 className="text-xl font-semibold">{monthNames[month]} {year}</h2>
            <button onClick={handlePrevMonth} className="px-3 py-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700" aria-label="Previous month">&lt;</button>
            <button onClick={handleNextMonth} className="px-3 py-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700" aria-label="Next month">&gt;</button>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => handleOpenAddModal('travel')} className="inline-flex items-center gap-2 px-3 py-2 text-xs font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700">
                <BriefcaseIcon className="w-4 h-4" />
                Add Travel
            </button>
             <button onClick={() => handleOpenAddModal('meeting')} className="inline-flex items-center gap-2 px-3 py-2 text-xs font-medium text-white bg-green-600 rounded-lg hover:bg-green-700">
                <UsersIcon className="w-4 h-4" />
                Add Meeting
            </button>
          </div>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center text-sm font-medium text-gray-600 dark:text-gray-400">
          {daysOfWeek.map(day => <div key={day} className="py-2">{day}</div>)}
        </div>
        <div className="grid grid-cols-7 gap-1 mt-1">
          {Array.from({ length: firstDayOfMonth }).map((_, i) => (
            <div key={`empty-${i}`} className="border border-transparent rounded-lg"></div>
          ))}
          {Array.from({ length: daysInMonth }).map((_, day) => {
            const dayNumber = day + 1;
            const isToday = today.getDate() === dayNumber && today.getMonth() === month && today.getFullYear() === year;
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNumber).padStart(2, '0')}`;
            const dayEvents = events[dateStr] || [];

            return (
              <div 
                key={dayNumber} 
                onClick={() => dayEvents.length > 0 && handleOpenViewModal(dateStr)}
                className={`p-2 h-14 md:h-20 border rounded-lg flex flex-col items-center justify-start text-sm transition-colors
                  ${isToday ? 'bg-blue-600 text-white font-bold' : 'border-gray-200 dark:border-gray-700'}
                  ${dayEvents.length > 0 ? 'cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700/50' : ''}
                `}
              >
                <span>{dayNumber}</span>
                {dayEvents.length > 0 && (
                   <div className="flex justify-center items-center gap-1 mt-1 flex-wrap">
                      {dayEvents.slice(0, 3).map(event => ( // Show max 3 dots
                          <div key={event.id} className={`w-2 h-2 rounded-full ${event.type === 'travel' ? 'bg-blue-400 dark:bg-blue-500' : 'bg-green-400 dark:bg-green-500'}`}></div>
                      ))}
                   </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
      
      {/* Add Event Modal */}
      <Modal isOpen={isAddModalOpen} onClose={handleCloseAddModal} title={eventType === 'travel' ? 'Add Travel Plan' : 'Add Meeting Plan'}>
        <form onSubmit={handleSaveEvent} className="space-y-4">
           <div>
              <label htmlFor="event-title" className="block mb-1 text-sm font-medium text-gray-900 dark:text-white">Title</label>
              <input 
                id="event-title"
                name="title"
                type="text"
                required
                defaultValue={eventType === 'travel' ? 'Travel Plan' : 'Meeting Plan'}
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white"
              />
           </div>
           <div>
              <label htmlFor="event-date" className="block mb-1 text-sm font-medium text-gray-900 dark:text-white">Date</label>
              <input 
                id="event-date"
                name="date"
                type="date"
                required
                defaultValue={new Date().toISOString().split('T')[0]}
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white"
              />
           </div>
            <div>
              <label htmlFor="event-description" className="block mb-1 text-sm font-medium text-gray-900 dark:text-white">Description</label>
              <textarea
                id="event-description"
                name="description"
                rows={4}
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white"
                placeholder="Add details about your plan..."
              ></textarea>
           </div>
           <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={handleCloseAddModal} className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500">
                    Cancel
                </button>
                <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700">
                    Save Event
                </button>
           </div>
        </form>
      </Modal>

      {/* View Events Modal */}
      <Modal isOpen={isViewModalOpen} onClose={handleCloseViewModal} title={`Events for ${selectedDate ? new Date(selectedDate + 'T00:00:00').toLocaleDateString() : ''}`}>
        <div className="space-y-4 max-h-96 overflow-y-auto">
          {selectedDate && events[selectedDate]?.length > 0 ? (
            events[selectedDate].map(event => (
              <div key={event.id} className={`p-4 rounded-lg border-l-4 ${event.type === 'travel' ? 'bg-blue-50 border-blue-500 dark:bg-blue-900/50' : 'bg-green-50 border-green-500 dark:bg-green-900/50'}`}>
                <div className="flex justify-between items-center">
                   <h4 className="font-bold text-lg text-gray-900 dark:text-white">{event.title}</h4>
                   <span className={`px-2 py-1 text-xs font-medium rounded-full ${event.type === 'travel' ? 'bg-blue-200 text-blue-800 dark:bg-blue-800 dark:text-blue-200' : 'bg-green-200 text-green-800 dark:bg-green-800 dark:text-green-200'}`}>
                    {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                   </span>
                </div>
                <p className="mt-2 text-sm text-gray-600 dark:text-gray-300 whitespace-pre-wrap">{event.description}</p>
              </div>
            ))
          ) : (
            <p className="text-gray-500 dark:text-gray-400">No events scheduled for this day.</p>
          )}
        </div>
         <div className="flex justify-end mt-4">
            <button onClick={handleCloseViewModal} className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500">
                Close
            </button>
         </div>
      </Modal>
    </div>
  );
};

export default Calendar;
