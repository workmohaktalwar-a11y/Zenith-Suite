import React, { useState, useEffect, useMemo } from 'react';

interface CalculatorProps {
  initialCost: number | string;
  initialMrp: number | string;
  initialGst: number | string;
  initialFeeb: number | string;
  onUpdate: (cost: number, mrp: number, gst: number, feeb: number) => void;
}

type CalcMode = 'standard' | 'findMrp' | 'findCost';

const InputRow: React.FC<{
  label: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  name: string;
  type?: string;
  step?: string;
  readOnly?: boolean;
}> = ({ label, value, onChange, name, type = 'number', step = '0.01', readOnly = false, ...props }) => (
  <div className="grid grid-cols-2 items-center gap-4">
    <label htmlFor={name} className="text-sm font-medium text-gray-700 dark:text-gray-300">{label}</label>
    <input
      id={name}
      name={name}
      type={type}
      step={step}
      value={value}
      onChange={onChange}
      readOnly={readOnly}
      className={`bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ${readOnly ? 'cursor-not-allowed bg-gray-200 dark:bg-gray-600' : ''}`}
      {...props}
    />
  </div>
);

const ResultRow: React.FC<{label: string, value: string}> = ({ label, value }) => (
  <div className="grid grid-cols-2 items-center gap-4 py-2 px-3 bg-gray-100 dark:bg-gray-700/50 rounded-lg">
    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{label}</span>
    <span className="text-sm font-semibold text-gray-900 dark:text-white text-right pr-2">{value}</span>
  </div>
);

const ModeSelector: React.FC<{mode: CalcMode, setMode: (mode: CalcMode) => void}> = ({ mode, setMode }) => (
    <div className="grid grid-cols-3 text-center text-sm font-medium text-gray-500 dark:text-gray-400 border border-gray-200 dark:border-gray-600 rounded-lg overflow-hidden">
        <button onClick={() => setMode('standard')} className={`p-2 ${mode === 'standard' ? 'bg-blue-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}>Standard</button>
        <button onClick={() => setMode('findMrp')} className={`p-2 border-l border-r border-gray-200 dark:border-gray-600 ${mode === 'findMrp' ? 'bg-blue-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}>Find MRP</button>
        <button onClick={() => setMode('findCost')} className={`p-2 ${mode === 'findCost' ? 'bg-blue-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}>Find Cost</button>
    </div>
);


const Calculator: React.FC<CalculatorProps> = ({ initialCost, initialMrp, initialGst, initialFeeb, onUpdate }) => {
  const [mode, setMode] = useState<CalcMode>('standard');
  
  const [cost, setCost] = useState(Number(initialCost) || 0);
  const [mrp, setMrp] = useState(Number(initialMrp) || 0);
  const [gstPercent, setGstPercent] = useState(Number(initialGst) || 18);
  const [feebPercent, setFeebPercent] = useState(Number(initialFeeb) || 0);
  
  const [desiredMargin, setDesiredMargin] = useState(0);
  const [desiredMarkup, setDesiredMarkup] = useState(0);

  const calculations = useMemo(() => {
    const gstRate = gstPercent / 100;
    const feebRate = feebPercent / 100;

    const finalCost = cost * (1 + gstRate);
    const revenuePreTax = mrp > 0 ? mrp / (1 + gstRate) : 0;
    
    const feebAmount = revenuePreTax * feebRate;
    const profit = revenuePreTax - finalCost - feebAmount;
    
    const margin = revenuePreTax > 0 ? (profit / revenuePreTax) * 100 : 0;
    const markup = finalCost > 0 ? (profit / finalCost) * 100 : 0;
    const gstOnSale = mrp - revenuePreTax;
    
    return { revenuePreTax, profit, margin, markup, gstOnSale, finalCost, feebAmount };
  }, [cost, mrp, gstPercent, feebPercent]);

  useEffect(() => {
    if (mode === 'standard') {
        setDesiredMargin(calculations.margin);
        setDesiredMarkup(calculations.markup);
    }
  }, [calculations.margin, calculations.markup, mode]);

  const handleDesiredMarginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newMargin = parseFloat(e.target.value) || 0;
    setDesiredMargin(newMargin);
    const gstRate = gstPercent / 100;
    const feebRate = feebPercent / 100;
    const marginRate = newMargin / 100;

    if (mode === 'findMrp') {
      if ((1 - marginRate - feebRate) > 0 && cost > 0) {
        const finalCost = cost * (1 + gstRate);
        const newRevenue = finalCost / (1 - marginRate - feebRate);
        const newMrp = newRevenue * (1 + gstRate);
        setMrp(newMrp);
      }
    } else if (mode === 'findCost') {
      if ((1 - marginRate - feebRate) > 0 && mrp > 0) {
        const revenuePreTax = mrp / (1 + gstRate);
        const newFinalCost = revenuePreTax * (1 - marginRate - feebRate);
        const newCost = newFinalCost / (1 + gstRate);
        setCost(newCost);
      }
    }
  };

  const handleDesiredMarkupChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newMarkup = parseFloat(e.target.value) || 0;
    setDesiredMarkup(newMarkup);
    const gstRate = gstPercent / 100;
    const feebRate = feebPercent / 100;
    const markupRate = newMarkup / 100;

    if (mode === 'findMrp' && cost > 0 && (1 - feebRate > 0)) {
        const finalCost = cost * (1 + gstRate);
        const newRevenue = (finalCost * (1 + markupRate)) / (1 - feebRate);
        const newMrp = newRevenue * (1 + gstRate);
        setMrp(newMrp);
    }
  };
  
  const handleInputChange = (setter: React.Dispatch<React.SetStateAction<number>>) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setter(parseFloat(e.target.value) || 0);
  };

  const formatCurrency = (value: number) => isNaN(value) ? '0.00' : value.toFixed(2);
  const formatPercent = (value: number) => isNaN(value) ? '0.00' : value.toFixed(2);

  // Helper to show empty string for zero values in inputs for better UX
  const stringify = (val: number) => val === 0 ? '' : String(val);

  return (
    <div className="space-y-4">
      <ModeSelector mode={mode} setMode={setMode} />

      <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg space-y-3">
        <h4 className="font-semibold text-blue-800 dark:text-blue-300">Primary Fields</h4>
        <InputRow label="Cost" name="cost" value={String(cost)} onChange={handleInputChange(setCost)} readOnly={mode === 'findCost'} />
        <InputRow label="MRP" name="mrp" value={String(mrp)} onChange={handleInputChange(setMrp)} readOnly={mode === 'findMrp'} />
        <InputRow label="GST %" name="gst" value={String(gstPercent)} onChange={handleInputChange(setGstPercent)} />
        <InputRow label="FEEB %" name="feeb" value={String(feebPercent)} onChange={handleInputChange(setFeebPercent)} />
      </div>

      {mode !== 'standard' && (
        <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg space-y-3">
            <h4 className="font-semibold text-yellow-800 dark:text-yellow-300">Reverse Calculation</h4>
            {mode === 'findMrp' && (
                <>
                    <p className="text-xs text-center text-gray-500 dark:text-gray-400">Enter your target margin or markup to calculate the required MRP.</p>
                    <InputRow label="Desired Margin %" name="desiredMargin" value={String(desiredMargin)} onChange={handleDesiredMarginChange} />
                    <InputRow label="Desired Markup %" name="desiredMarkup" value={String(desiredMarkup)} onChange={handleDesiredMarkupChange} />
                </>
            )}
             {mode === 'findCost' && (
                <>
                    <p className="text-xs text-center text-gray-500 dark:text-gray-400">Enter your target margin to calculate the maximum cost.</p>
                    <InputRow label="Desired Margin %" name="desiredMargin" value={String(desiredMargin)} onChange={handleDesiredMarginChange} />
                </>
            )}
        </div>
      )}

      <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg space-y-2">
        <h4 className="font-semibold text-green-800 dark:text-green-300">Results</h4>
        <ResultRow label="Final Cost" value={formatCurrency(calculations.finalCost)} />
        <ResultRow label="Revenue (Pre-Tax)" value={formatCurrency(calculations.revenuePreTax)} />
        <ResultRow label="Marketplace Fee" value={formatCurrency(calculations.feebAmount)} />
        <ResultRow label="Profit" value={formatCurrency(calculations.profit)} />
        <ResultRow label="Margin %" value={`${formatPercent(calculations.margin)} %`} />
        <ResultRow label="Markup %" value={`${formatPercent(calculations.markup)} %`} />
        <ResultRow label="GST on Sale" value={formatCurrency(calculations.gstOnSale)} />
      </div>
      
      <div className="flex justify-end pt-2">
        <button 
          onClick={() => onUpdate(cost, mrp, gstPercent, feebPercent)}
          className="px-6 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700"
        >
            Update Product
        </button>
      </div>
    </div>
  );
};

export default Calculator;
