import React, { useEffect, useState } from 'react';
import { ExternalLinkIcon } from './icons';

interface APIInitErrorScreenProps {
  error: string;
}

const APIInitErrorScreen: React.FC<APIInitErrorScreenProps> = ({ error }) => {
  const [origin, setOrigin] = useState('');

  useEffect(() => {
    // This will run on the client-side and get the exact origin
    setOrigin(window.location.origin);
  }, []);


  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-900 p-4">
      <div className="text-center p-6 md:p-8 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-3xl w-full mx-auto">
        <h1 className="text-2xl md:text-3xl font-bold text-red-600 dark:text-red-400">Action Required: Fix API Configuration</h1>
        
        <div className="mt-4 text-left p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-500/30 rounded-lg">
            <p className="font-semibold text-red-800 dark:text-red-300">Error Message:</p>
            <p className="text-sm text-red-700 dark:text-red-400 break-words">{error}</p>
        </div>

        <div className="mt-6 text-left space-y-4">
          <div>
            <h2 className="font-semibold text-lg text-gray-800 dark:text-gray-100">What This Error Means</h2>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Your app was blocked by Google when it tried to load information about the Drive and Sheets APIs. This is a configuration issue in the Google Cloud Console, not a bug in the app's code. It's almost always caused by the <strong>API Key</strong> not being authorized for this website.
            </p>
          </div>
        </div>

        <div className="mt-6 text-left bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
          <h2 className="font-semibold text-lg text-gray-800 dark:text-gray-100">How to Fix It (Step-by-Step)</h2>
          <ol className="list-decimal list-inside mt-2 space-y-3 text-sm text-gray-700 dark:text-gray-300">
            <li>
              Go to your{' '}
              <a
                href="https://console.cloud.google.com/apis/credentials"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline dark:text-blue-400 font-semibold"
              >
                Google Cloud Credentials page
              </a>.
            </li>
            <li>
              Click on the name of the <strong>API Key</strong> used in this app (the one in `constants.ts`).
            </li>
            <li>
              Under <strong>Application restrictions</strong>, ensure <strong>HTTP referrers (web sites)</strong> is selected.
            </li>
            <li>
              Under <strong>Website restrictions</strong>, click <strong>ADD A REFERRER</strong>. This is the most critical step. Copy the exact URL below and paste it into the field.
              {origin ? (
                  <div className="text-base p-3 my-2 bg-blue-100 dark:bg-blue-900/50 border border-blue-300 dark:border-blue-600 rounded-lg font-mono text-blue-900 dark:text-blue-200 break-all">
                    {origin}
                  </div>
              ) : (
                 <div className="text-sm p-2 my-2 bg-gray-200 dark:bg-gray-600 rounded">
                    Loading your app's URL...
                 </div>
              )}
            </li>
            <li>
              Click <strong>Save</strong>. Changes can take up to 5 minutes to apply. After saving, refresh this page.
            </li>
          </ol>
        </div>
        
        <div className="mt-6 text-left bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg">
           <h2 className="font-semibold text-lg text-gray-800 dark:text-gray-100">Troubleshooting Checklist</h2>
           <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">If the error persists after following the steps above, manually verify every item on this list.</p>
           <ul className="space-y-2 text-sm text-gray-700 dark:text-gray-300">
                <li className="flex items-start"><span className="mr-2 text-green-500">✔</span><div><strong>APIs Enabled:</strong> In the Google Cloud Console, go to "Enabled APIs & services". Are both "Google Drive API" and "Google Sheets API" on the list?</div></li>
                <li className="flex items-start"><span className="mr-2 text-green-500">✔</span><div><strong>HTTP Referrer Saved:</strong> Did you add the URL from the blue box above to your API Key's "Website restrictions" and click the SAVE button?</div></li>
                <li className="flex items-start"><span className="mr-2 text-green-500">✔</span><div><strong>Wait 5 Minutes:</strong> Have you waited at least 5 minutes since saving the API Key changes? Google's updates are not always instant.</div></li>
                <li className="flex items-start"><span className="mr-2 text-green-500">✔</span><div><strong>Billing Enabled:</strong> Is a valid billing account linked to your Google Cloud project? Some APIs require this for activation, even for free usage.</div></li>
           </ul>
        </div>

        <a
          href="https://console.cloud.google.com/apis/credentials"
          target="_blank"
          rel="noopener noreferrer"
          className="mt-8 w-full inline-flex items-center justify-center px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-md transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
        >
          <ExternalLinkIcon className="w-5 h-5 mr-2" />
          Go to Google Cloud Credentials
        </a>
      </div>
    </div>
  );
};

export default APIInitErrorScreen;
