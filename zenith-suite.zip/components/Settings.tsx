import React, { useState, useEffect, useRef } from 'react';
import { getCurrentUser, getUserProfile, saveUserProfile, UserProfile } from '../services/authService';
import { UserCircleIcon, PencilSquareIcon } from './icons';

const Settings: React.FC = () => {
  const [isDarkMode, setIsDarkMode] = useState(() => {
    // Initialize state from localStorage or default to system preference
    if (localStorage.theme === 'dark') {
      return true;
    }
    if (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return true;
    }
    return false;
  });

  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [organisation, setOrganisation] = useState('');
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  useEffect(() => {
    // Load user profile
    const currentUserEmail = getCurrentUser();
    if (currentUserEmail) {
      setEmail(currentUserEmail);
      const profile = getUserProfile(currentUserEmail);
      if (profile) {
        setPhone(profile.phone || '');
        setOrganisation(profile.organisation || '');
        setProfilePicture(profile.profilePicture || null);
      }
    }
  }, []);

  const toggleTheme = () => {
    setIsDarkMode(prevMode => !prevMode);
  };

  const handleProfileSave = () => {
    setSaveStatus('saving');
    const profileData: UserProfile = {
        email,
        phone,
        organisation,
        profilePicture,
    };
    saveUserProfile(profileData);
    setTimeout(() => {
        setSaveStatus('saved');
        setTimeout(() => setSaveStatus('idle'), 2000);
    }, 1000); // Simulate save delay
  };

  const handlePictureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
        const file = e.target.files[0];
        const reader = new FileReader();
        reader.onloadend = () => {
            setProfilePicture(reader.result as string);
        };
        reader.readAsDataURL(file);
    }
  };

  const Card: React.FC<{title: string, children: React.ReactNode, className?: string}> = ({title, children, className}) => (
    <div className={`bg-white dark:bg-gray-800 p-6 rounded-lg shadow-soft ${className}`}>
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">{title}</h3>
      {children}
    </div>
  );

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Settings</h1>
      <p className="mt-1 text-gray-600 dark:text-gray-400">Manage your profile, application settings and preferences.</p>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-6xl">
        {/* Profile Card */}
        <Card title="Profile Information" className="lg:col-span-2">
            <div className="flex flex-col sm:flex-row items-center gap-6">
                 <div className="relative">
                    {profilePicture ? (
                        <img src={profilePicture} alt="Profile" className="w-24 h-24 rounded-full object-cover"/>
                    ) : (
                        <UserCircleIcon className="w-24 h-24 text-gray-300 dark:text-gray-600" />
                    )}
                    <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="absolute bottom-0 right-0 p-1 bg-blue-600 rounded-full text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                        aria-label="Change profile picture"
                    >
                        <PencilSquareIcon className="w-4 h-4" />
                    </button>
                    <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handlePictureUpload}
                    />
                </div>
                <div className="flex-grow w-full space-y-4">
                     <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email Address</label>
                        <input type="email" id="email" value={email} readOnly className="mt-1 block w-full bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-gray-500 dark:text-gray-400 cursor-not-allowed"/>
                    </div>
                </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
                <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Phone Number</label>
                    <input 
                        type="tel" 
                        id="phone"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="e.g., +1 555-123-4567"
                        className="mt-1 block w-full bg-gray-50 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    />
                </div>
                 <div>
                    <label htmlFor="organisation" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Organisation</label>
                    <input 
                        type="text" 
                        id="organisation"
                        value={organisation}
                        onChange={(e) => setOrganisation(e.target.value)}
                        placeholder="e.g., Acme Corporation"
                        className="mt-1 block w-full bg-gray-50 dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    />
                </div>
            </div>
            <div className="mt-6 flex justify-end">
                <button 
                    onClick={handleProfileSave}
                    disabled={saveStatus === 'saving'}
                    className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-400 disabled:cursor-wait"
                >
                    {saveStatus === 'saving' ? 'Saving...' : (saveStatus === 'saved' ? 'Saved!' : 'Save Profile')}
                </button>
            </div>
        </Card>

        {/* Settings Cards */}
        <div className="space-y-6">
            <Card title="Appearance">
                <div className="flex items-center justify-between">
                    <span className="text-gray-700 dark:text-gray-300">Dark Mode</span>
                    <button
                        onClick={toggleTheme}
                        className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-900 ${
                        isDarkMode ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600'
                        }`}
                    >
                        <span
                        className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform duration-300 ${
                            isDarkMode ? 'translate-x-6' : 'translate-x-1'
                        }`}
                        />
                    </button>
                </div>
                <p className="mt-3 text-sm text-gray-500 dark:text-gray-400">
                    Switch between light and dark themes. Your preference will be saved for your next visit.
                </p>
            </Card>

            <Card title="About the App">
                <div className="text-sm text-gray-700 dark:text-gray-300 space-y-2">
                    <p>This application was created by Mohak Talwar.</p>
                    <p>All rights are reserved by the owner. Copying the process or any part of this application without permission is a punishable offense.</p>
                </div>
            </Card>
        </div>
      </div>
    </div>
  );
};

export default Settings;