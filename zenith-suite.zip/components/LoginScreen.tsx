
import React from 'react';
import { GoogleIcon } from './icons';

interface LoginScreenProps {
  onSignIn: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onSignIn }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh]">
      <div className="text-center p-8 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-sm w-full">
        <h1 className="text-4xl font-bold text-blue-600 dark:text-blue-400">BuySheet Pro</h1>
        <p className="mt-4 text-gray-600 dark:text-gray-300">
          Your mobile-first solution for creating buying sheets on the go.
        </p>
        <div className="mt-8">
          <button
            onClick={onSignIn}
            className="w-full inline-flex items-center justify-center px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-md transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
          >
            <GoogleIcon />
            Sign in with Google
          </button>
        </div>
        <p className="mt-6 text-xs text-gray-500 dark:text-gray-400">
          By signing in, you agree to allow this app to create and manage files in your Google Drive.
        </p>
      </div>
    </div>
  );
};

export default LoginScreen;
