import React, { useState, useRef } from 'react';
import { CameraIcon } from './icons';

const BackupPicture: React.FC = () => {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Picture Backup</h1>
      <p className="mt-1 text-gray-600 dark:text-gray-400">Upload an image to create a backup.</p>

      <div className="mt-8 max-w-2xl mx-auto bg-white dark:bg-gray-800 p-8 rounded-lg shadow-soft">
        <div className="flex justify-center items-center w-full h-64 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg overflow-hidden">
          {imagePreview ? (
            <img src={imagePreview} alt="Preview" className="h-full w-full object-contain" />
          ) : (
            <div className="text-center text-gray-500 dark:text-gray-400">
              <CameraIcon className="mx-auto h-12 w-12" />
              <p className="mt-2 text-sm">Image preview will appear here</p>
            </div>
          )}
        </div>

        <input
          type="file"
          accept="image/*"
          ref={fileInputRef}
          onChange={handleImageChange}
          className="hidden"
        />

        <div className="mt-6 flex justify-center">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-6 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            {imagePreview ? 'Choose a Different Image' : 'Choose an Image'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default BackupPicture;
