import React from 'react';
import { Page } from './MainAppLayout';
import { 
  ChartPieIcon, 
  DocumentPlusIcon, 
  CameraIcon, 
  CalendarDaysIcon, 
  CalculatorIcon, 
  ArrowRightOnRectangleIcon,
  Cog6ToothIcon,
  SparklesIcon
} from './icons';

interface SidebarProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  onLogout: () => void;
}

const navItems: { page: Exclude<Page, 'settings'>; label: string; icon: React.FC<{className?: string}> }[] = [
  { page: 'dashboard', label: 'Dashboard', icon: ChartPieIcon },
  { page: 'buysheet', label: 'Buy Sheet', icon: DocumentPlusIcon },
  { page: 'fashion', label: 'Fashion Feed', icon: SparklesIcon },
  { page: 'backup', label: 'Picture Backup', icon: CameraIcon },
  { page: 'calendar', label: 'Calendar', icon: CalendarDaysIcon },
  { page: 'calculator', label: 'Calculator', icon: CalculatorIcon },
];

const Sidebar: React.FC<SidebarProps> = ({ currentPage, setCurrentPage, onLogout }) => {
  return (
    <aside className="flex flex-col items-center w-16 sm:w-20 bg-white dark:bg-gray-800 shadow-md">
      <div className="flex items-center justify-center h-16 sm:h-20 border-b border-gray-200 dark:border-gray-700 w-full">
        <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">Z</span>
      </div>
      <nav className="flex-1 mt-4 space-y-2">
        {navItems.map(item => (
          <button
            key={item.page}
            onClick={() => setCurrentPage(item.page)}
            className={`relative flex items-center justify-center w-12 h-12 rounded-lg group ${
              currentPage === item.page
                ? 'bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-300'
                : 'text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
            }`}
            aria-label={item.label}
          >
            <item.icon className="w-6 h-6" />
            <span className="absolute left-full ml-4 w-auto p-2 min-w-max rounded-md shadow-md text-white bg-gray-900 dark:bg-black text-xs font-bold transition-all duration-100 scale-0 origin-left group-hover:scale-100">
              {item.label}
            </span>
          </button>
        ))}
      </nav>
      <div className="mb-4 space-y-2">
         <button
            key="settings"
            onClick={() => setCurrentPage('settings')}
            className={`relative flex items-center justify-center w-12 h-12 rounded-lg group ${
              currentPage === 'settings'
                ? 'bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-300'
                : 'text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
            }`}
            aria-label="Settings"
          >
            <Cog6ToothIcon className="w-6 h-6" />
            <span className="absolute left-full ml-4 w-auto p-2 min-w-max rounded-md shadow-md text-white bg-gray-900 dark:bg-black text-xs font-bold transition-all duration-100 scale-0 origin-left group-hover:scale-100">
              Settings
            </span>
          </button>
        <button
          onClick={onLogout}
          className="relative flex items-center justify-center w-12 h-12 rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 group"
          aria-label="Logout"
        >
          <ArrowRightOnRectangleIcon className="w-6 h-6" />
           <span className="absolute left-full ml-4 w-auto p-2 min-w-max rounded-md shadow-md text-white bg-gray-900 dark:bg-black text-xs font-bold transition-all duration-100 scale-0 origin-left group-hover:scale-100">
              Logout
            </span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;