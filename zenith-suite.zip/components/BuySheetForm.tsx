import React, { useState, useCallback, useEffect } from 'react';
import { Product, BuyType, BuySheet } from '../types';
import ProductCard from './ProductCard';
import { PlusIcon, DownloadIcon } from './icons';
import Spinner from './Spinner';
import { saveBuySheet, getBuySheet } from '../services/localStorageService';
import { exportToExcel } from '../services/googleApiService';

interface BuySheetFormProps {
  buySheet: BuySheet;
  onBack: () => void;
}

const createNewProduct = (): Product => ({
  id: `product_${Date.now()}_${Math.random()}`,
  // Excel fields
  mcDesc: '',
  articleNumber: '',
  hsn: '',
  setRatio: '',
  setNo: '',
  fabricSubFabric: '',
  brand: '',
  pkSzRatio: '',
  styleSubStyle: '',
  size: '',
  design: '',
  colorFamily: '',
  color: '#ffffff',
  option: '',
  subDiv: '',
  ssn: '',
  seg: '',
  qty: 1, // Default qty to 1
  cost: '', // Net Cost
  frtAndWh: 0,
  mrp: '',
  gst: 12, // Default GST from screenshot
  feeb: 0,
  
  // App specific
  buyType: BuyType.DOMESTIC,
  currency: 'USD',
  exchangeRate: '',
  imageFile: null,
  imagePreview: null,
});

const BuySheetForm: React.FC<BuySheetFormProps> = ({ buySheet, onBack }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [sheetName, setSheetName] = useState(buySheet.name);
  const [isSaving, setIsSaving] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
      const loadedSheet = getBuySheet(buySheet.id);
      if (loadedSheet) {
        setProducts(loadedSheet.products.length > 0 ? loadedSheet.products : [createNewProduct()]);
        setSheetName(loadedSheet.name);
      } else {
        setProducts([createNewProduct()]);
      }
  }, [buySheet.id]);


  const handleProductChange = useCallback((index: number, updatedProduct: Product) => {
    setProducts(prevProducts => {
      const newProducts = [...prevProducts];
      if (updatedProduct.imageFile) {
          updatedProduct.imageFile = null;
      }
      newProducts[index] = updatedProduct;
      return newProducts;
    });
  }, []);

  const addProduct = () => {
    setProducts(prev => [...prev, createNewProduct()]);
  };

  const removeProduct = (index: number) => {
    const newProducts = products.filter((_, i) => i !== index);
    if (newProducts.length === 0) {
        setProducts([createNewProduct()]);
    } else {
        setProducts(newProducts);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setError(null);
    setSuccessMessage(null);
    
    try {
      const productsToSave = products.filter(p => p.articleNumber || p.mcDesc);
      const updatedSheet: BuySheet = {
          ...buySheet,
          name: sheetName,
          products: productsToSave
      };
      saveBuySheet(updatedSheet);
      setSuccessMessage(`BuySheet "${sheetName}" saved successfully!`);
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err: any) {
      setError(err.message || 'An unknown error occurred while saving.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDownload = async () => {
    setIsDownloading(true);
    try {
      const currentSheetState: BuySheet = {
        ...buySheet,
        name: sheetName,
        products: products,
      };
      await exportToExcel(currentSheetState);
    } catch (err) {
      console.error("Failed to download excel", err);
      setError("Failed to generate Excel file. Check console for details.");
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
        <div>
          <input 
            type="text"
            value={sheetName}
            onChange={(e) => setSheetName(e.target.value)}
            className="text-2xl font-bold w-full text-gray-800 dark:text-white bg-transparent border-none focus:ring-0 p-0"
            aria-label="BuySheet Name"
          />
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Click "Save BuySheet" to persist changes.
          </p>
        </div>
        <div className="flex items-center gap-2 w-full sm:w-auto">
            <button 
              onClick={handleDownload} 
              disabled={isDownloading}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600 flex items-center gap-2 disabled:bg-gray-300 dark:disabled:bg-gray-600 disabled:cursor-not-allowed"
            >
              {isDownloading ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-gray-600 dark:text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Downloading...
                </>
              ) : (
                <>
                  <DownloadIcon className="w-4 h-4"/>
                  Download Excel
                </>
              )}
            </button>
            <button onClick={onBack} className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600">
              Back to Dashboard
            </button>
        </div>
      </div>

      {isSaving && <Spinner message="Saving your buysheet..." />}
      {error && <div className="p-3 bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300 rounded-lg">{error}</div>}
      {successMessage && <div className="p-3 bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300 rounded-lg">{successMessage}</div>}

      <div className="space-y-6">
        {products.map((product, index) => (
          <ProductCard
            key={product.id}
            product={product}
            index={index}
            onChange={handleProductChange}
            onRemove={removeProduct}
            isOnlyCard={products.length === 1}
          />
        ))}
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <button
          onClick={addProduct}
          className="flex items-center justify-center w-full sm:w-auto gap-2 px-5 py-2.5 text-sm font-medium text-center text-gray-900 bg-white border border-gray-300 rounded-lg hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700"
        >
          <PlusIcon className="w-5 h-5"/> Add Another Product
        </button>
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="w-full sm:w-auto text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-8 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 disabled:bg-blue-400 disabled:cursor-not-allowed"
        >
          {isSaving ? 'Saving...' : `Save BuySheet`}
        </button>
      </div>
    </div>
  );
};

export default BuySheetForm;