import React, { useState, useEffect } from 'react';
// FIX: Import the 'Transition' type from framer-motion to resolve the type error.
import { motion, AnimatePresence, Transition } from 'framer-motion';
import Sidebar from './Sidebar';
import Dashboard from './Dashboard';
import BuySheetCreator from './BuySheetCreator';
import BackupPicture from './BackupPicture';
import Calendar from './Calendar';
import SmartCalculator from './SmartCalculator';
import Settings from './Settings';
import FashionFeed from './FashionFeed';

export type Page = 'dashboard' | 'buysheet' | 'fashion' | 'backup' | 'calendar' | 'calculator' | 'settings';

interface MainAppLayoutProps {
  onLogout: () => void;
}

const pageComponents: Record<Page, React.FC> = {
  dashboard: Dashboard,
  buysheet: BuySheetCreator,
  fashion: FashionFeed,
  backup: BackupPicture,
  calendar: Calendar,
  calculator: SmartCalculator,
  settings: Settings,
};

const MainAppLayout: React.FC<MainAppLayoutProps> = ({ onLogout }) => {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');

  useEffect(() => {
    // On app load, check theme from localStorage and apply it
    const savedTheme = localStorage.getItem('theme') || 'light';
    if (savedTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  const ActiveComponent = pageComponents[currentPage];

  const pageVariants = {
    initial: { opacity: 0, y: 20 },
    in: { opacity: 1, y: 0 },
    out: { opacity: 0, y: -20 },
  };

  // FIX: Explicitly type 'pageTransition' with the 'Transition' type. This ensures that properties like 'type' and 'ease' are correctly inferred as literal types ('tween', 'anticipate') instead of the generic 'string', satisfying framer-motion's strict type requirements.
  const pageTransition: Transition = {
    type: 'tween',
    ease: 'anticipate',
    duration: 0.5,
  };

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
      <Sidebar currentPage={currentPage} setCurrentPage={setCurrentPage} onLogout={onLogout} />
      <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial="initial"
            animate="in"
            exit="out"
            variants={pageVariants}
            transition={pageTransition}
          >
            <ActiveComponent />
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
};

export default MainAppLayout;