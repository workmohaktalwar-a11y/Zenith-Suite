
import React from 'react';

interface SpinnerProps {
    message?: string;
}

const Spinner: React.FC<SpinnerProps> = ({ message }) => {
    return (
        <div className="flex flex-col items-center justify-center h-screen -mt-20">
            <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent border-solid rounded-full animate-spin"></div>
            {message && <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">{message}</p>}
        </div>
    );
};

export default Spinner;
