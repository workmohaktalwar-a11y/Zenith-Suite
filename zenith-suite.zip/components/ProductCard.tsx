import React, { useCallback, useMemo, useState, useRef } from 'react';
import { Product, BuyType } from '../types';
import { CalculatorIcon, TrashIcon, PhotoIcon, CameraIcon } from './icons';
import Modal from './Modal';
import Calculator from './Calculator';

interface ProductCardProps {
    product: Product;
    index: number;
    onChange: (index: number, product: Product) => void;
    onRemove: (index: number) => void;
    isOnlyCard: boolean;
}

const InputField = React.memo(({ label, id, ...props }: React.InputHTMLAttributes<HTMLInputElement> & { label: string; }) => (
    <div>
        <label htmlFor={id} className="block mb-1 text-sm font-medium text-gray-900 dark:text-white">{label}</label>
        <input id={id} {...props} className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" />
    </div>
));

const ProductCard: React.FC<ProductCardProps> = ({ product, index, onChange, onRemove, isOnlyCard }) => {

    const [isCalculatorOpen, setCalculatorOpen] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const cameraInputRef = useRef<HTMLInputElement>(null);

    const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        let finalValue: string | number = value;

        if (type === 'number') {
            finalValue = value === '' ? '' : parseFloat(value);
        }
        
        onChange(index, { ...product, [name]: finalValue });

    }, [index, onChange, product]);

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onloadend = () => {
                onChange(index, {
                    ...product,
                    imageFile: file,
                    imagePreview: reader.result as string,
                });
            };
            reader.readAsDataURL(file);
        }
         e.target.value = ''; // Reset input to allow re-uploading the same file
    };

    const handleBuyTypeChange = (newType: BuyType) => {
        onChange(index, { ...product, buyType: newType });
    };

    const handleCalculatorUpdate = useCallback((newCost: number, newMrp: number, newGst: number, newFeeb: number) => {
        onChange(index, {
            ...product,
            cost: newCost,
            mrp: newMrp,
            gst: newGst,
            feeb: newFeeb,
        });
        setCalculatorOpen(false);
    }, [index, onChange, product]);

    const memoizedFields = useMemo(() => (
        <div className="space-y-4">
            {/* Row 1 */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <InputField label="MC-DESC" id={`mcDesc-${product.id}`} name="mcDesc" value={product.mcDesc} onChange={handleChange} />
                <InputField label="Art No" id={`articleNumber-${product.id}`} name="articleNumber" value={product.articleNumber} onChange={handleChange} />
                <InputField label="HSN" id={`hsn-${product.id}`} name="hsn" value={product.hsn} onChange={handleChange} />
            </div>
            
            {/* Row 2 */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <InputField label="Set Ratio" id={`setRatio-${product.id}`} name="setRatio" value={product.setRatio} onChange={handleChange} />
                <InputField label="Set No" id={`setNo-${product.id}`} name="setNo" value={product.setNo} onChange={handleChange} />
                <InputField label="Fabric/Sub-Fabric" id={`fabricSubFabric-${product.id}`} name="fabricSubFabric" value={product.fabricSubFabric} onChange={handleChange} />
                <InputField label="Brand" id={`brand-${product.id}`} name="brand" value={product.brand} onChange={handleChange} />
            </div>
            
            {/* Row 3 */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <InputField label="PK_SZ Ratio" id={`pkSzRatio-${product.id}`} name="pkSzRatio" value={product.pkSzRatio} onChange={handleChange} />
                <InputField label="Style/Sub-Style" id={`styleSubStyle-${product.id}`} name="styleSubStyle" value={product.styleSubStyle} onChange={handleChange} />
                <InputField label="Size" id={`size-${product.id}`} name="size" value={product.size} onChange={handleChange} />
                <InputField label="Design" id={`design-${product.id}`} name="design" value={product.design} onChange={handleChange} />
            </div>
            
            {/* Row 4: Color fields */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <InputField label="Color Family" id={`colorFamily-${product.id}`} name="colorFamily" value={product.colorFamily} onChange={handleChange} />
                <div>
                    <label htmlFor={`color-${product.id}`} className="block mb-1 text-sm font-medium text-gray-900 dark:text-white">Color</label>
                    <div className="flex items-center gap-2">
                        <div className="relative flex-grow">
                            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                <span className="w-5 h-5 rounded-full border border-gray-400" style={{ backgroundColor: product.color }}></span>
                            </div>
                            <input 
                                type="text"
                                id={`color-${product.id}`} 
                                name="color" 
                                value={product.color} 
                                onChange={handleChange}
                                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                placeholder="#RRGGBB"
                            />
                        </div>
                        <input 
                            type="color" 
                            value={product.color} 
                            onChange={handleChange} 
                            name="color" 
                            className="h-[42px] w-12 p-1 bg-white border border-gray-300 rounded-lg cursor-pointer dark:bg-gray-700 dark:border-gray-600"
                            aria-label="Color picker"
                        />
                    </div>
                </div>
                <InputField label="Option" id={`option-${product.id}`} name="option" value={product.option} onChange={handleChange} />
            </div>

            {/* Row 5 */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <InputField label="Sub-Div" id={`subDiv-${product.id}`} name="subDiv" value={product.subDiv} onChange={handleChange} />
                <InputField label="SSN" id={`ssn-${product.id}`} name="ssn" value={product.ssn} onChange={handleChange} />
                <InputField label="SEG" id={`seg-${product.id}`} name="seg" value={product.seg} onChange={handleChange} />
            </div>

            {/* Row 6: Pricing */}
            <div>
                <div className="flex justify-between items-center mb-2">
                    <label className="text-sm font-medium text-gray-900 dark:text-white">Pricing & Quantity</label>
                    <button 
                        type="button" 
                        onClick={() => setCalculatorOpen(true)}
                        className="flex items-center gap-1 text-sm text-blue-600 dark:text-blue-400 hover:underline"
                        aria-label="Open pricing calculator"
                    >
                        <CalculatorIcon className="w-4 h-4" />
                        Calculator
                    </button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    <InputField label="QTY" id={`qty-${product.id}`} name="qty" value={product.qty} onChange={handleChange} type="number" />
                    <InputField label="Net Cost" id={`cost-${product.id}`} name="cost" value={product.cost} onChange={handleChange} type="number" step="0.01" />
                    <InputField label="MRP" id={`mrp-${product.id}`} name="mrp" value={product.mrp} onChange={handleChange} type="number" step="0.01" />
                    <InputField label="FRT & WH %" id={`frtAndWh-${product.id}`} name="frtAndWh" value={product.frtAndWh} onChange={handleChange} type="number" step="0.01" />
                    <InputField label="Tax %" id={`gst-${product.id}`} name="gst" value={product.gst} onChange={handleChange} type="number" />
                    <InputField label="FEEB %" id={`feeb-${product.id}`} name="feeb" value={product.feeb} onChange={handleChange} type="number" step="0.01" />
                </div>
            </div>
            
            {/* Row 7: Buy Type (Domestic/Import) */}
            <div>
                <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Buy Type</label>
                <div className="flex rounded-lg shadow-sm w-full sm:w-auto">
                    <button type="button" onClick={() => handleBuyTypeChange(BuyType.DOMESTIC)} className={`px-4 py-2 text-sm font-medium w-1/2 ${product.buyType === BuyType.DOMESTIC ? 'bg-blue-600 text-white' : 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white'} rounded-l-md border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600 focus:z-10 focus:ring-2 focus:ring-blue-500`}>
                        Domestic
                    </button>
                    <button type="button" onClick={() => handleBuyTypeChange(BuyType.IMPORT)} className={`-ml-px px-4 py-2 text-sm font-medium w-1/2 ${product.buyType === BuyType.IMPORT ? 'bg-blue-600 text-white' : 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white'} rounded-r-md border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600 focus:z-10 focus:ring-2 focus:ring-blue-500`}>
                        Import
                    </button>
                </div>
            </div>

            {product.buyType === BuyType.IMPORT && (
                <div className="p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <InputField label="Currency" id={`currency-${product.id}`} name="currency" value={product.currency} onChange={handleChange} />
                    <InputField label="Exchange Rate" id={`exchangeRate-${product.id}`} name="exchangeRate" value={product.exchangeRate} onChange={handleChange} type="number" step="0.01" />
                </div>
            )}
        </div>
    ), [product, handleChange, handleBuyTypeChange]);

    return (
        <React.Fragment>
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 md:p-6 relative">
                {!isOnlyCard && (
                     <button onClick={() => onRemove(index)} className="absolute top-3 right-3 p-1.5 bg-red-100 dark:bg-red-900/50 rounded-full text-red-500 hover:bg-red-200 dark:hover:bg-red-800 transition-colors">
                        <TrashIcon className="w-5 h-5"/>
                    </button>
                )}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="md:col-span-2 space-y-4">
                        {memoizedFields}
                    </div>
                     <div className="space-y-4">
                        <label className="block text-sm font-medium text-gray-900 dark:text-white">Product Image</label>
                        
                        <div className="w-full h-64 border-2 border-gray-300 border-dashed rounded-lg bg-gray-50 dark:bg-gray-700 dark:border-gray-600 flex items-center justify-center overflow-hidden">
                            {product.imagePreview ? (
                                <img src={product.imagePreview} alt="Product preview" className="object-cover w-full h-full" />
                            ) : (
                                <div className="text-center text-gray-500 dark:text-gray-400">
                                    <PhotoIcon className="mx-auto h-12 w-12" />
                                    <p className="mt-2 text-sm">No image selected</p>
                                </div>
                            )}
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                            <button
                                type="button"
                                onClick={() => fileInputRef.current?.click()}
                                className="flex items-center justify-center gap-2 w-full px-4 py-2 text-sm font-medium text-center text-gray-900 bg-white border border-gray-300 rounded-lg hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700"
                            >
                                <PhotoIcon className="w-5 h-5"/>
                                {product.imagePreview ? 'Replace File' : 'Upload File'}
                            </button>
                            <button
                                type="button"
                                onClick={() => cameraInputRef.current?.click()}
                                className="flex items-center justify-center gap-2 w-full px-4 py-2 text-sm font-medium text-center text-gray-900 bg-white border border-gray-300 rounded-lg hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700"
                            >
                                <CameraIcon className="w-5 h-5" />
                                Use Camera
                            </button>
                        </div>
                        
                        <input 
                            ref={fileInputRef}
                            type="file" 
                            className="hidden" 
                            accept="image/*" 
                            onChange={handleImageChange} 
                        />
                        <input 
                            ref={cameraInputRef}
                            type="file" 
                            className="hidden" 
                            accept="image/*" 
                            capture="environment"
                            onChange={handleImageChange} 
                        />
                    </div>
                </div>
            </div>
            <Modal isOpen={isCalculatorOpen} onClose={() => setCalculatorOpen(false)} title="Pricing & Margin Calculator">
                <Calculator 
                    initialCost={product.cost}
                    initialMrp={product.mrp}
                    initialGst={product.gst}
                    initialFeeb={product.feeb}
                    onUpdate={handleCalculatorUpdate}
                />
            </Modal>
        </React.Fragment>
    );
};

export default React.memo(ProductCard);