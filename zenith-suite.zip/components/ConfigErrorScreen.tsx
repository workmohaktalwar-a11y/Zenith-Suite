
import React from 'react';
import { ExternalLinkIcon } from './icons';

const ConfigErrorScreen: React.FC = () => {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 dark:bg-gray-900">
      <div className="text-center p-8 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-lg w-full mx-4">
        <h1 className="text-3xl font-bold text-red-600 dark:text-red-400">Configuration Error</h1>
        <p className="mt-4 text-gray-600 dark:text-gray-300">
          This application requires a Google Client ID to function, but it has not been configured correctly.
        </p>
        <div className="mt-6 text-left bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
          <h2 className="font-semibold text-lg text-gray-800 dark:text-gray-100">Action Required:</h2>
          <ol className="list-decimal list-inside mt-2 space-y-2 text-sm text-gray-700 dark:text-gray-300">
            <li>
              Go to the{' '}
              <a
                href="https://console.cloud.google.com/apis/credentials"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline dark:text-blue-400"
              >
                Google Cloud Console
              </a>.
            </li>
            <li>Create or select an existing OAuth 2.0 Client ID for a "Web application".</li>
            <li>
              Copy the Client ID and paste it into the `GOOGLE_CLIENT_ID` variable in the `constants.ts` file.
            </li>
             <li className="!mt-4 pt-2 border-t border-gray-300 dark:border-gray-600">
              <span className="font-bold">Note:</span> A Client ID for a web app is different from a Service Account. Do not use a Service Account email or ID here.
            </li>
          </ol>
        </div>
        <a
          href="https://console.cloud.google.com/apis/credentials"
          target="_blank"
          rel="noopener noreferrer"
          className="mt-8 w-full inline-flex items-center justify-center px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-md transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
        >
          <ExternalLinkIcon className="w-5 h-5 mr-2" />
          Go to Google Cloud Console
        </a>
      </div>
    </div>
  );
};

export default ConfigErrorScreen;