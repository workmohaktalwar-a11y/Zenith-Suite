import React from 'react';
import { getCurrentUser } from '../services/authService';

const Dashboard: React.FC = () => {
  const userEmail = getCurrentUser();

  const Card: React.FC<{title: string, value: string, description: string}> = ({title, value, description}) => (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-soft transition-transform transform hover:scale-105">
      <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</h3>
      <p className="mt-1 text-3xl font-semibold text-gray-900 dark:text-white">{value}</p>
      <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">{description}</p>
    </div>
  );

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
      <p className="mt-1 text-gray-600 dark:text-gray-400">Welcome back, {userEmail || 'User'}!</p>

      <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <Card title="Active Buy Sheets" value="12" description="+2 from last week" />
        <Card title="Total Products" value="1,402" description="Across all sheets" />
        <Card title="Pending Backups" value="3" description="Images to be uploaded" />
        <Card title="Upcoming Events" value="5" description="In the next 30 days" />
        <Card title="Total Calculations" value="256" description="Performed this month" />
        <Card title="User Status" value="Active" description="Account is in good standing" />
      </div>
    </div>
  );
};

export default Dashboard;
