import React, { useState, useEffect, useCallback } from 'react';
import { BuySheet } from '../types';
import { getBuySheets, createNewBuySheet, deleteBuySheet } from '../services/localStorageService';
import BuySheetForm from './BuySheetForm';
import { PlusIcon, TrashIcon } from './icons';

const BuySheetCreator: React.FC = () => {
  const [buySheets, setBuySheets] = useState<BuySheet[]>([]);
  const [selectedSheet, setSelectedSheet] = useState<BuySheet | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadSheets = useCallback(() => {
    setIsLoading(true);
    const sheets = getBuySheets();
    setBuySheets(sheets.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    setIsLoading(false);
  }, []);

  useEffect(() => {
    loadSheets();
  }, [loadSheets]);

  const handleCreateNew = () => {
    const newSheet = createNewBuySheet();
    setSelectedSheet(newSheet);
  };

  const handleSelectSheet = (sheet: BuySheet) => {
    setSelectedSheet(sheet);
  };

  const handleDeleteSheet = (id: string) => {
    if (window.confirm('Are you sure you want to delete this buy sheet? This action cannot be undone.')) {
      deleteBuySheet(id);
      loadSheets();
    }
  };

  const handleBack = () => {
    setSelectedSheet(null);
    loadSheets(); // Reload sheets in case of changes
  };

  if (selectedSheet) {
    return <BuySheetForm buySheet={selectedSheet} onBack={handleBack} />;
  }
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  }

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Buy Sheets</h1>
          <p className="mt-1 text-gray-600 dark:text-gray-400">Manage your existing buy sheets or create a new one.</p>
        </div>
        <button
          onClick={handleCreateNew}
          className="inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 w-full sm:w-auto"
        >
          <PlusIcon className="w-5 h-5" />
          Create New Sheet
        </button>
      </div>

      {isLoading ? (
        <div className="text-center p-8 text-gray-500 dark:text-gray-400">Loading sheets...</div>
      ) : buySheets.length > 0 ? (
        <div className="space-y-4">
          {buySheets.map(sheet => (
            <div key={sheet.id} className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-soft flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex-grow">
                <h3 className="font-semibold text-lg text-gray-900 dark:text-white">{sheet.name}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Created on {formatDate(sheet.createdAt)} &bull; {sheet.products.length} product(s)
                </p>
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  onClick={() => handleSelectSheet(sheet)}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 flex-grow sm:flex-grow-0"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDeleteSheet(sheet.id)}
                  className="p-2 text-sm font-medium text-red-600 bg-red-100 rounded-lg hover:bg-red-200 dark:bg-red-900/50 dark:text-red-300 dark:hover:bg-red-800"
                  aria-label={`Delete ${sheet.name}`}
                >
                  <TrashIcon className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center bg-white dark:bg-gray-800 p-12 rounded-lg shadow-soft">
          <h3 className="text-xl font-medium text-gray-900 dark:text-white">No Buy Sheets Found</h3>
          <p className="mt-2 text-gray-500 dark:text-gray-400">Get started by creating your first buy sheet.</p>
          <button
            onClick={handleCreateNew}
            className="mt-6 inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <PlusIcon className="w-5 h-5" />
            Create Your First Sheet
          </button>
        </div>
      )}
    </div>
  );
};

export default BuySheetCreator;
