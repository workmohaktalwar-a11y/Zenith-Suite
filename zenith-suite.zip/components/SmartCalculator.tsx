import React, { useState, useEffect, useMemo } from 'react';

type CalcMode = 'standard' | 'findMrp' | 'findCost';

const InputRow: React.FC<{
  label: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  name: string;
  type?: string;
  step?: string;
  readOnly?: boolean;
}> = ({ label, value, onChange, name, type = 'number', step = '0.01', readOnly = false, ...props }) => (
  <div className="grid grid-cols-2 items-center gap-4">
    <label htmlFor={name} className="text-sm font-medium text-gray-700 dark:text-gray-300">{label}</label>
    <input
      id={name}
      name={name}
      type={type}
      step={step}
      value={value}
      onChange={onChange}
      readOnly={readOnly}
      className={`bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ${readOnly ? 'cursor-not-allowed bg-gray-200 dark:bg-gray-600' : ''}`}
      {...props}
    />
  </div>
);

const ResultRow: React.FC<{label: string, value: string}> = ({ label, value }) => (
  <div className="grid grid-cols-2 items-center gap-4 py-2 px-3 bg-gray-100 dark:bg-gray-700/50 rounded-lg">
    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{label}</span>
    <span className="text-sm font-semibold text-gray-900 dark:text-white text-right pr-2">{value}</span>
  </div>
);

const ModeSelector: React.FC<{mode: CalcMode, setMode: (mode: CalcMode) => void}> = ({ mode, setMode }) => (
    <div className="grid grid-cols-3 text-center text-sm font-medium text-gray-500 dark:text-gray-400 border border-gray-200 dark:border-gray-600 rounded-lg overflow-hidden">
        <button onClick={() => setMode('standard')} className={`p-2 ${mode === 'standard' ? 'bg-blue-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}>Standard</button>
        <button onClick={() => setMode('findMrp')} className={`p-2 border-l border-r border-gray-200 dark:border-gray-600 ${mode === 'findMrp' ? 'bg-blue-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}>Find MRP</button>
        <button onClick={() => setMode('findCost')} className={`p-2 ${mode === 'findCost' ? 'bg-blue-600 text-white' : 'hover:bg-gray-100 dark:hover:bg-gray-700'}`}>Find Cost</button>
    </div>
);

const SmartCalculator: React.FC = () => {
  const [mode, setMode] = useState<CalcMode>('standard');
  
  const [cost, setCost] = useState(100);
  const [mrp, setMrp] = useState(200);
  const [gstPercent, setGstPercent] = useState(18);
  
  const [desiredMargin, setDesiredMargin] = useState(0);
  const [desiredMarkup, setDesiredMarkup] = useState(0);

  const calculations = useMemo(() => {
    const gstRate = gstPercent / 100;
    const finalCost = cost * (1 + gstRate);
    const revenuePreTax = mrp > 0 ? mrp / (1 + gstRate) : 0;
    const profit = revenuePreTax - finalCost;
    
    const margin = revenuePreTax > 0 ? (profit / revenuePreTax) * 100 : 0;
    const markup = finalCost > 0 ? (profit / finalCost) * 100 : 0;
    const gstOnSale = mrp - revenuePreTax;
    
    return { revenuePreTax, profit, margin, markup, gstOnSale, finalCost };
  }, [cost, mrp, gstPercent]);

  useEffect(() => {
    if (mode === 'standard') {
        setDesiredMargin(calculations.margin);
        setDesiredMarkup(calculations.markup);
    }
  }, [calculations.margin, calculations.markup, mode]);

  const handleDesiredMarginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newMargin = parseFloat(e.target.value) || 0;
    setDesiredMargin(newMargin);
    const gstRate = gstPercent / 100;
    const marginRate = newMargin / 100;

    if (mode === 'findMrp') {
      if (marginRate < 1 && cost > 0) {
        const finalCost = cost * (1 + gstRate);
        const newRevenue = finalCost / (1 - marginRate);
        const newMrp = newRevenue * (1 + gstRate);
        setMrp(newMrp);
      }
    } else if (mode === 'findCost') {
      if (marginRate < 1 && mrp > 0) {
        const revenuePreTax = mrp / (1 + gstRate);
        const newFinalCost = revenuePreTax * (1 - marginRate);
        const newCost = newFinalCost / (1 + gstRate);
        setCost(newCost);
      }
    }
  };

  const handleDesiredMarkupChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newMarkup = parseFloat(e.target.value) || 0;
    setDesiredMarkup(newMarkup);
    const gstRate = gstPercent / 100;
    const markupRate = newMarkup / 100;

    if (mode === 'findMrp') {
      if (cost > 0) {
        const finalCost = cost * (1 + gstRate);
        const newRevenue = finalCost * (1 + markupRate);
        const newMrp = newRevenue * (1 + gstRate);
        setMrp(newMrp);
      }
    }
  };
  
  const handleInputChange = (setter: React.Dispatch<React.SetStateAction<number>>) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setter(parseFloat(e.target.value) || 0);
  };

  const formatCurrency = (value: number) => isNaN(value) ? '0.00' : value.toFixed(2);
  const formatPercent = (value: number) => isNaN(value) ? '0.00' : value.toFixed(2);

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white">MRP & Margin Calculator</h1>
      <p className="mt-1 text-gray-600 dark:text-gray-400">A smart tool for all your buying calculations.</p>
      
      <div className="mt-8 mx-auto max-w-lg bg-white dark:bg-gray-800 p-6 rounded-lg shadow-soft space-y-4">
        <ModeSelector mode={mode} setMode={setMode} />

        <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg space-y-3">
          <h4 className="font-semibold text-blue-800 dark:text-blue-300">Primary Fields</h4>
          <InputRow label="Cost" name="cost" value={cost.toString()} onChange={handleInputChange(setCost)} readOnly={mode === 'findCost'} />
          <InputRow label="MRP" name="mrp" value={mrp.toString()} onChange={handleInputChange(setMrp)} readOnly={mode === 'findMrp'} />
          <InputRow label="GST %" name="gst" value={gstPercent.toString()} onChange={handleInputChange(setGstPercent)} />
        </div>

        {mode !== 'standard' && (
          <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg space-y-3">
              <h4 className="font-semibold text-yellow-800 dark:text-yellow-300">Reverse Calculation</h4>
              {mode === 'findMrp' && (
                  <>
                      <p className="text-xs text-center text-gray-500 dark:text-gray-400">Enter your target margin or markup to calculate the required MRP.</p>
                      <InputRow label="Desired Margin %" name="desiredMargin" value={desiredMargin.toString()} onChange={handleDesiredMarginChange} />
                      <InputRow label="Desired Markup %" name="desiredMarkup" value={desiredMarkup.toString()} onChange={handleDesiredMarkupChange} />
                  </>
              )}
               {mode === 'findCost' && (
                  <>
                      <p className="text-xs text-center text-gray-500 dark:text-gray-400">Enter your target margin to calculate the maximum cost.</p>
                      <InputRow label="Desired Margin %" name="desiredMargin" value={desiredMargin.toString()} onChange={handleDesiredMarginChange} />
                  </>
              )}
          </div>
        )}

        <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg space-y-2">
          <h4 className="font-semibold text-green-800 dark:text-green-300">Results</h4>
          <ResultRow label="Final Cost" value={formatCurrency(calculations.finalCost)} />
          <ResultRow label="Revenue (Pre-Tax)" value={formatCurrency(calculations.revenuePreTax)} />
          <ResultRow label="Profit" value={formatCurrency(calculations.profit)} />
          <ResultRow label="Margin %" value={`${formatPercent(calculations.margin)} %`} />
          <ResultRow label="Markup %" value={`${formatPercent(calculations.markup)} %`} />
          <ResultRow label="GST on Sale" value={formatCurrency(calculations.gstOnSale)} />
        </div>
      </div>
    </div>
  );
};

export default SmartCalculator;