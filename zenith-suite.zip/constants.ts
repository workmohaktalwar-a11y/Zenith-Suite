
export const MERCHANDISE_CATEGORIES = [
    "Men's Apparel",
    "Women's Apparel",
    "Kid's Apparel",
    "Footwear",
    "Accessories",
    "Home Goods",
    "Electronics",
    "Beauty & Personal Care",
    "Sports & Outdoors"
];