// This file now contains the Excel Export Service logic using ExcelJS.
import { BuySheet } from '../types';

// Global declaration for ExcelJS to fix TypeScript errors.
declare var ExcelJS: any;

export const exportToExcel = async (buySheet: BuySheet) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('BuySheet');

  // --- Column Headers ---
  const headers = [
    'IMAGE', 'SN', 'MC-DESC', 'ART NO', 'HSN', 'SET RATIO', 'SET_NO', 'FABRIC-SUB_FABRIC',
    'BRAND', 'PK_SZ RATIO', 'STYLE-SUB_STYLE', 'SIZE', 'DESIGN', 'COLOR FAMILY',
    'COLOR', 'OPTION', 'SUB-DIV', 'SSN', 'SEG', 'QTY', 'NET COST', 'FRT & WH',
    'MRP', 'FEEB %', 'PURCHASE VALUE', 'TAX (INWARD)', 'TAX (OUTWARD)', 'TOTAL SALES',
    'FINAL COST', 'NET SALES', 'NET MARGIN-V', 'NET MARGIN %'
  ];

  // Set headers and basic formatting
  worksheet.columns = headers.map(header => ({
    header: header,
    key: header,
    width: header === 'IMAGE' ? 25 : (header.length > 10 ? 20 : 15),
    style: { alignment: { vertical: 'middle', horizontal: 'left', wrapText: true } }
  }));

  const headerRow = worksheet.getRow(1);
  headerRow.font = { bold: true };
  headerRow.alignment = { vertical: 'middle', horizontal: 'center' };
  
  // --- Add Data Rows ---
  for (const [index, p] of buySheet.products.entries()) {
    // Calculations
    const qty = Number(p.qty) || 0;
    const cost = Number(p.cost) || 0;
    const mrp = Number(p.mrp) || 0;
    const gstPercent = Number(p.gst) || 0;
    const frtAndWhPercent = Number(p.frtAndWh) || 0;
    const feebPercent = Number(p.feeb) || 0;
    const gstRate = gstPercent / 100;
    const feebRate = feebPercent / 100;

    const purchaseValue = qty * cost;
    const totalSales = qty * mrp;
    const finalCost = purchaseValue * (1 + gstRate);
    const netSales = totalSales / (1 + gstRate);
    
    const feebAmount = netSales * feebRate;
    const profit = netSales - finalCost - feebAmount;

    const netMargin = netSales > 0 ? (profit / netSales) : 0;

    // Add row data object
    const rowData = {
      'SN': index + 1,
      'MC-DESC': p.mcDesc,
      'ART NO': p.articleNumber,
      'HSN': p.hsn,
      'SET RATIO': p.setRatio,
      'SET_NO': p.setNo,
      'FABRIC-SUB_FABRIC': p.fabricSubFabric,
      'BRAND': p.brand,
      'PK_SZ RATIO': p.pkSzRatio,
      'STYLE-SUB_STYLE': p.styleSubStyle,
      'SIZE': p.size,
      'DESIGN': p.design,
      'COLOR FAMILY': p.colorFamily,
      'COLOR': p.color,
      'OPTION': p.option,
      'SUB-DIV': p.subDiv,
      'SSN': p.ssn,
      'SEG': p.seg,
      'QTY': qty,
      'NET COST': cost,
      'FRT & WH': frtAndWhPercent / 100, // Store as decimal for % format
      'MRP': mrp,
      'FEEB %': feebRate,
      'PURCHASE VALUE': purchaseValue,
      'TAX (INWARD)': gstRate,
      'TAX (OUTWARD)': gstRate,
      'TOTAL SALES': totalSales,
      'FINAL COST': finalCost,
      'NET SALES': netSales,
      'NET MARGIN-V': profit,
      'NET MARGIN %': netMargin, // Store as decimal for % format
    };
    const row = worksheet.addRow(rowData);
    
    // Set a fixed height for all data rows to accommodate images
    row.height = 100;

    // Add image if it exists
    if (p.imagePreview) {
      try {
        const base64Image = p.imagePreview.split(',')[1];
        const imageId = workbook.addImage({
          base64: base64Image,
          extension: 'png',
        });

        worksheet.addImage(imageId, {
          tl: { col: 0.1, row: index + 1.1 }, // Top-left corner with a small margin
          ext: { width: 120, height: 120 },   // Extent (size) of the image
        });
      } catch (e) {
        console.error("Could not add image for product", p.articleNumber, e);
        worksheet.getCell(`A${index + 2}`).value = 'Image Error';
      }
    }
    
    // Cell Formatting
    const rowIndex = index + 2; // +1 for 1-based index, +1 for header row
    worksheet.getCell(`U${rowIndex}`).numFmt = '#,##0.00'; // NET COST
    worksheet.getCell(`V${rowIndex}`).numFmt = '0.00%'; // FRT & WH
    worksheet.getCell(`W${rowIndex}`).numFmt = '#,##0.00'; // MRP
    worksheet.getCell(`X${rowIndex}`).numFmt = '0.00%'; // FEEB %
    worksheet.getCell(`Y${rowIndex}`).numFmt = '#,##0.00'; // PURCHASE VALUE
    worksheet.getCell(`Z${rowIndex}`).numFmt = '0.00%'; // TAX INWARD
    worksheet.getCell(`AA${rowIndex}`).numFmt = '0.00%'; // TAX OUTWARD
    worksheet.getCell(`AB${rowIndex}`).numFmt = '#,##0.00'; // TOTAL SALES
    worksheet.getCell(`AC${rowIndex}`).numFmt = '#,##0.00'; // FINAL COST
    worksheet.getCell(`AD${rowIndex}`).numFmt = '#,##0.00'; // NET SALES
    worksheet.getCell(`AE${rowIndex}`).numFmt = '#,##0.00'; // NET MARGIN-V
    worksheet.getCell(`AF${rowIndex}`).numFmt = '0.00%'; // NET MARGIN %
  }

  // --- Generate and Download File ---
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${buySheet.name.replace(/[\s/]/g, '_')}.xlsx`;
  a.click();
  window.URL.revokeObjectURL(url);
};