export type EventType = 'travel' | 'meeting';

export interface CalendarEvent {
  id: string;
  type: EventType;
  title: string;
  date: string; // YYYY-MM-DD format
  description: string;
}

const EVENTS_KEY = 'zenith_calendar_events';

/**
 * Retrieves all calendar events from local storage.
 */
export const getEvents = (): CalendarEvent[] => {
  const data = localStorage.getItem(EVENTS_KEY);
  return data ? JSON.parse(data) : [];
};

/**
 * Saves a new event to local storage.
 * @param eventData The event data to save, without an ID.
 * @returns The newly created event with an ID.
 */
export const saveEvent = (eventData: Omit<CalendarEvent, 'id'>): CalendarEvent => {
  const events = getEvents();
  const newEvent: CalendarEvent = {
    ...eventData,
    id: `event_${Date.now()}_${Math.random()}`,
  };
  events.push(newEvent);
  localStorage.setItem(EVENTS_KEY, JSON.stringify(events));
  return newEvent;
};
