import { BuySheet, Product } from '../types';

const BUYSHEETS_KEY = 'buySheets';

export const getBuySheets = (): BuySheet[] => {
    const data = localStorage.getItem(BUYSHEETS_KEY);
    return data ? JSON.parse(data) : [];
};

export const getBuySheet = (id: string): BuySheet | undefined => {
    const buySheets = getBuySheets();
    return buySheets.find(sheet => sheet.id === id);
};

export const saveBuySheet = (buySheetToSave: BuySheet): void => {
    let buySheets = getBuySheets();
    const existingIndex = buySheets.findIndex(sheet => sheet.id === buySheetToSave.id);

    if (existingIndex > -1) {
        buySheets[existingIndex] = buySheetToSave;
    } else {
        buySheets.push(buySheetToSave);
    }
    localStorage.setItem(BUYSHEETS_KEY, JSON.stringify(buySheets));
};

export const createNewBuySheet = (): BuySheet => {
    const now = new Date();
    const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  
    const newSheet: BuySheet = {
        id: `buysheet_${Date.now()}`,
        name: `BuySheet - ${formattedDate}`,
        createdAt: now.toISOString(),
        products: [],
    };
    saveBuySheet(newSheet);
    return newSheet;
};


export const deleteBuySheet = (id: string): void => {
    let buySheets = getBuySheets();
    buySheets = buySheets.filter(sheet => sheet.id !== id);
    localStorage.setItem(BUYSHEETS_KEY, JSON.stringify(buySheets));
};
