const USERS_KEY = 'zenith_users';
const CURRENT_USER_KEY = 'zenith_current_user';
const PROFILES_KEY = 'zenith_profiles'; // New key

// Mock user type
interface User {
  email: string;
  passwordHash: string; // In a real app, never store plain text passwords
}

// New Profile type
export interface UserProfile {
  email: string;
  phone: string;
  organisation: string;
  profilePicture: string | null; // base64 string
}

// Helper to get users from localStorage
const getUsers = (): User[] => {
  const users = localStorage.getItem(USERS_KEY);
  return users ? JSON.parse(users) : [];
};

// Helper to save users to localStorage
const saveUsers = (users: User[]) => {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

// Helper to get profiles from localStorage
const getProfiles = (): Record<string, UserProfile> => {
    const profiles = localStorage.getItem(PROFILES_KEY);
    return profiles ? JSON.parse(profiles) : {};
};

// Helper to save profiles to localStorage
const saveProfiles = (profiles: Record<string, UserProfile>) => {
    localStorage.setItem(PROFILES_KEY, JSON.stringify(profiles));
};

export const signUpUser = (email: string, password: string): { success: boolean; message: string } => {
  const users = getUsers();
  if (users.some(user => user.email === email)) {
    return { success: false, message: 'An account with this email already exists.' };
  }
  
  // In a real app, you'd hash the password here.
  // For this mock, we'll store it as is, but name the field `passwordHash` as a reminder.
  const newUser: User = { email, passwordHash: password };
  users.push(newUser);
  saveUsers(users);

  // Automatically log in the user after sign up
  localStorage.setItem(CURRENT_USER_KEY, email);
  
  return { success: true, message: 'Account created successfully!' };
};

export const loginUser = (email: string, password: string): { success: boolean; message: string } => {
  const users = getUsers();
  const user = users.find(u => u.email === email);

  if (!user) {
    return { success: false, message: 'No account found with this email.' };
  }

  if (user.passwordHash !== password) {
    return { success: false, message: 'Incorrect password.' };
  }

  localStorage.setItem(CURRENT_USER_KEY, email);
  return { success: true, message: 'Logged in successfully!' };
};

export const logoutUser = (): void => {
  localStorage.removeItem(CURRENT_USER_KEY);
};

export const getCurrentUser = (): string | null => {
  return localStorage.getItem(CURRENT_USER_KEY);
};

// New functions for profile management
export const getUserProfile = (email: string): UserProfile | null => {
    const profiles = getProfiles();
    return profiles[email] || null;
};

export const saveUserProfile = (profile: UserProfile): void => {
    const profiles = getProfiles();
    profiles[profile.email] = profile;
    saveProfiles(profiles);
};
