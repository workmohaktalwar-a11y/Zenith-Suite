export enum BuyType {
  DOMESTIC = 'Domestic',
  IMPORT = 'Import',
}

export interface Product {
  id: string;
  // --- Fields from Excel Screenshot ---
  mcDesc: string;
  articleNumber: string;
  hsn: string;
  setRatio: string;
  setNo: string;
  fabricSubFabric: string;
  brand:string;
  pkSzRatio: string;
  styleSubStyle: string;
  size: string;
  design: string;
  colorFamily: string;
  color: string;
  option: string;
  subDiv: string;
  ssn: string;
  seg: string;
  qty: number | string;
  cost: number | string; // NET COST
  frtAndWh: number | string;
  mrp: number | string;
  gst: number | string; // Corresponds to TAX %
  feeb: number | string;
  
  // --- App-specific fields ---
  buyType: BuyType; // Kept for Domestic/Import logic
  currency: string; // For import
  exchangeRate: number | string; // For import
  imageFile: File | null;
  imagePreview: string | null;
}

export interface BuySheet {
  id: string;
  name: string;
  createdAt: string;
  products: Product[];
}

// Global declaration for ExcelJS
declare var ExcelJS: any;